if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface IndexApps_Params {
    title?: Resource;
    currentBreakpoint?: string;
    apps?: AppItem[];
}
import { MyAppSource } from "@normalized:N&&&entry/src/main/ets/model/HomeDataType&";
import type { AppItem } from "@normalized:N&&&entry/src/main/ets/model/HomeDataType&";
export default class IndexApps extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.title = undefined;
        this.__currentBreakpoint = this.createStorageProp('currentBreakpoint', 'md', "currentBreakpoint");
        this.apps = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: IndexApps_Params) {
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.apps !== undefined) {
            this.apps = params.apps;
        }
    }
    updateStateVars(params: IndexApps_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentBreakpoint.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentBreakpoint.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private title?: Resource;
    private __currentBreakpoint: ObservedPropertyAbstractPU<string>;
    get currentBreakpoint() {
        return this.__currentBreakpoint.get();
    }
    set currentBreakpoint(newValue: string) {
        this.__currentBreakpoint.set(newValue);
    }
    private apps: AppItem[];
    appListHeader(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/IndexApps.ets(10:5)", "entry");
            Row.margin({ bottom: 9, top: 9 });
            Row.width('100%');
            Row.alignItems(VerticalAlign.Bottom);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.title);
            Text.debugLine("entry/src/main/ets/common/IndexApps.ets(11:7)", "entry");
            Text.width(100);
            Text.fontSize(16);
            Text.textAlign(TextAlign.Start);
            Text.fontWeight(500);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/common/IndexApps.ets(16:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777244, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/IndexApps.ets(17:7)", "entry");
            Text.fontSize(14);
            Text.textAlign(TextAlign.End);
            Text.fontWeight(400);
            Text.margin({ right: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/common/IndexApps.ets(22:7)", "entry");
            Image.width(12);
            Image.height(18);
            Image.opacity(0.9);
            Image.objectFit(ImageFit.Fill);
        }, Image);
        Row.pop();
    }
    //关键代码
    appListItem(app: AppItem, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/IndexApps.ets(36:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(app.image);
            Image.debugLine("entry/src/main/ets/common/IndexApps.ets(37:7)", "entry");
            Image.width(this.currentBreakpoint === 'lg' ? 80 : 56);
            Image.height(this.currentBreakpoint === 'lg' ? 80 : 56);
            Image.margin({ bottom: 8 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(app.title);
            Text.debugLine("entry/src/main/ets/common/IndexApps.ets(41:7)", "entry");
            Text.width(this.currentBreakpoint === 'lg' ? 80 : 56);
            Text.height(16);
            Text.fontSize(12);
            Text.textAlign(TextAlign.Center);
            Text.fontColor('#18181A');
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777243, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/IndexApps.ets(48:7)", "entry");
            Text.width(this.currentBreakpoint === 'lg' ? 80 : 56);
            Text.height(28);
            Text.fontColor('#0A59F7');
            Text.textAlign(TextAlign.Center);
            Text.borderRadius(this.currentBreakpoint === 'lg' ? 26 : 20);
            Text.fontWeight(500);
            Text.fontSize(12);
            Text.padding({ top: 6, bottom: 6, left: 8, right: 8 });
            Text.backgroundColor('rgba(0,0,0,0.05)');
        }, Text);
        Text.pop();
        Column.pop();
    }
    //关键代码
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/IndexApps.ets(62:5)", "entry");
            Column.width('100%');
            Column.height(this.currentBreakpoint === 'lg' ? 188 : 164);
            Column.padding({ bottom: 8, left: 12, right: 12 });
        }, Column);
        this.appListHeader.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 借助List组件能力，实现延伸能力场景
            List.create({ space: this.currentBreakpoint === 'lg' ? 44 : 20 });
            List.debugLine("entry/src/main/ets/common/IndexApps.ets(65:7)", "entry");
            // 借助List组件能力，实现延伸能力场景
            List.width('100%');
            // 借助List组件能力，实现延伸能力场景
            List.height(this.currentBreakpoint === 'lg' ? 140 : 120);
            // 借助List组件能力，实现延伸能力场景
            List.listDirection(Axis.Horizontal);
        }, List);
        {
            const __lazyForEachItemGenFunction = _item => {
                const app = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(() => { }, false);
                        ListItem.debugLine("entry/src/main/ets/common/IndexApps.ets(67:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, ListItem);
                        // 每个应用的图标、名称及安装按钮
                        this.appListItem.bind(this)(app);
                        ListItem.pop();
                    };
                    observedDeepRender();
                }
            };
            LazyForEach.create("1", this, new MyAppSource(this.apps), __lazyForEachItemGenFunction);
            LazyForEach.pop();
        }
        // 借助List组件能力，实现延伸能力场景
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
