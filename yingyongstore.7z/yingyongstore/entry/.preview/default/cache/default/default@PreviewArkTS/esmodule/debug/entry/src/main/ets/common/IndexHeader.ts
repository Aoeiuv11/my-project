if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface IndexHeader_Params {
}
export default class IndexHeader extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: IndexHeader_Params) {
    }
    updateStateVars(params: IndexHeader_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //关键代码
    searchBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.End });
            Stack.debugLine("entry/src/main/ets/common/IndexHeader.ets(6:5)", "entry");
            Stack.height(56);
            Stack.width('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: { "id": 16777265, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } });
            TextInput.debugLine("entry/src/main/ets/common/IndexHeader.ets(7:7)", "entry");
            TextInput.placeholderColor('#FF000000');
            TextInput.placeholderFont({ size: 16, weight: 400 });
            TextInput.textAlign(TextAlign.Start);
            TextInput.caretColor('#FF000000');
            TextInput.width('100%');
            TextInput.height(40);
            TextInput.fontWeight(400);
            TextInput.padding({ top: 9, bottom: 9 });
            TextInput.fontSize(16);
            TextInput.backgroundColor(Color.White);
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/common/IndexHeader.ets(19:7)", "entry");
            Image.width(16);
            Image.height(16);
            Image.margin({ right: 20 });
        }, Image);
        Stack.pop();
    }
    titleBar(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777266, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/IndexHeader.ets(27:5)", "entry");
            Text.fontSize(24);
            Text.fontWeight(500);
            Text.fontColor('#18181A');
            Text.textAlign(TextAlign.Start);
            Text.height(56);
            Text.width('100%');
        }, Text);
        Text.pop();
    }
    //关键代码
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 借助栅格实现标题栏和搜索栏在不同断点下的不同布局效果。
            GridRow.create();
            GridRow.debugLine("entry/src/main/ets/common/IndexHeader.ets(39:5)", "entry");
            // 借助栅格实现标题栏和搜索栏在不同断点下的不同布局效果。
            GridRow.width('100%');
        }, GridRow);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            GridCol.create({ span: { xs: 12, lg: 8 } });
            GridCol.debugLine("entry/src/main/ets/common/IndexHeader.ets(40:7)", "entry");
        }, GridCol);
        this.titleBar.bind(this)();
        GridCol.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            GridCol.create({ span: { xs: 12, lg: 4 } });
            GridCol.debugLine("entry/src/main/ets/common/IndexHeader.ets(43:7)", "entry");
        }, GridCol);
        this.searchBar.bind(this)();
        GridCol.pop();
        // 借助栅格实现标题栏和搜索栏在不同断点下的不同布局效果。
        GridRow.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
