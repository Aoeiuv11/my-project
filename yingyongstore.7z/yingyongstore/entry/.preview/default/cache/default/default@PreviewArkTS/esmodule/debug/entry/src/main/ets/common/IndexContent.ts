if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface IndexContent_Params {
}
import IndexSwiper from "@normalized:N&&&entry/src/main/ets/common/IndexSwiper&";
import IndexEntrance from "@normalized:N&&&entry/src/main/ets/common/IndexEntrance&";
import IndexApps from "@normalized:N&&&entry/src/main/ets/common/IndexApps&";
import { appList, gameList } from "@normalized:N&&&entry/src/main/ets/model/HomeData&";
class IndexContent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: IndexContent_Params) {
    }
    updateStateVars(params: IndexContent_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/common/IndexContent.ets(10:5)", "entry");
            List.width("100%");
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    // 运营横幅
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/common/IndexContent.ets(12:7)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new IndexSwiper(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/common/IndexContent.ets", line: 13, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "IndexSwiper" });
                }
                // 运营横幅
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            // 运营横幅
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    // 快捷入口
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/common/IndexContent.ets(16:7)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new IndexEntrance(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/common/IndexContent.ets", line: 17, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "IndexEntrance" });
                }
                // 快捷入口
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            // 快捷入口
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    // 精品应用
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/common/IndexContent.ets(20:7)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new IndexApps(this, { title: { "id": 16777236, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, apps: appList }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/common/IndexContent.ets", line: 21, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    title: { "id": 16777236, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" },
                                    apps: appList
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "IndexApps" });
                }
                // 精品应用
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            // 精品应用
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    // 精品游戏
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/common/IndexContent.ets(24:7)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new IndexApps(this, { title: { "id": 16777237, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, apps: gameList }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/common/IndexContent.ets", line: 25, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {
                                    title: { "id": 16777237, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" },
                                    apps: gameList
                                };
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "IndexApps" });
                }
                // 精品游戏
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            // 精品游戏
            ListItem.pop();
        }
        List.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
