if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface IndexSwiper_Params {
    currentBreakpoint?: string;
}
export default class IndexSwiper extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentBreakpoint = this.createStorageProp('currentBreakpoint', 'md', "currentBreakpoint");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: IndexSwiper_Params) {
    }
    updateStateVars(params: IndexSwiper_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentBreakpoint.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentBreakpoint.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentBreakpoint: ObservedPropertyAbstractPU<string>;
    get currentBreakpoint() {
        return this.__currentBreakpoint.get();
    }
    set currentBreakpoint(newValue: string) {
        this.__currentBreakpoint.set(newValue);
    }
    swiperItem(imageSrc: Resource, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(imageSrc);
            Image.debugLine("entry/src/main/ets/common/IndexSwiper.ets(5:5)", "entry");
            Image.width('100%');
            Image.aspectRatio(2.5);
            Image.objectFit(ImageFit.Fill);
        }, Image);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Swiper.create();
            Swiper.debugLine("entry/src/main/ets/common/IndexSwiper.ets(12:5)", "entry");
            Swiper.autoPlay(true);
            Swiper.indicator(false);
            Swiper.itemSpace(10);
            Swiper.displayCount(this.currentBreakpoint === 'sm' ? 1 : (this.currentBreakpoint === 'md' ? 2 : 3));
            Swiper.width('100%');
            Swiper.padding({ left: 12, right: 12, bottom: 16, top: 16 });
        }, Swiper);
        this.swiperItem.bind(this)({ "id": 16777285, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
        this.swiperItem.bind(this)({ "id": 16777279, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
        this.swiperItem.bind(this)({ "id": 16777280, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
        Swiper.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
