// /model/HomeData   在resourse文件中放置以下资源文件，
interface AppItem {
    id: string;
    title: Resource;
    image: Resource;
}
const appList: AppItem[] = [
    { id: '0', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '1', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '2', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '3', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '4', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '5', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '6', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '7', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '8', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '9', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '10', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '11', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '12', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '13', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '14', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '15', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '16', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '17', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '18', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '19', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '20', title: { "id": 16777245, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777235, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } }
];
const gameList: AppItem[] = [
    { id: '21', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '22', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '23', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '24', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '25', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '26', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '27', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '28', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '29', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '30', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '31', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '32', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '33', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '34', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '35', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '36', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '37', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '38', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '39', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '40', title: { "id": 16777255, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777270, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } }
];
const entranceIcons: AppItem[] = [
    { id: '41', title: { "id": 16777238, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777271, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '42', title: { "id": 16777242, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777276, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '43', title: { "id": 16777240, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777283, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '44', title: { "id": 16777241, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777233, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
    { id: '45', title: { "id": 16777239, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, image: { "id": 16777277, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" } },
];
export { entranceIcons, appList, gameList };
