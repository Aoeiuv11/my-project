if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    currentIndex?: number;
    currentBreakpoint?: string;
    breakpointSystem?: BreakpointSystem;
    onTabChange?;
}
import Home from "@normalized:N&&&entry/src/main/ets/common/Home&";
import TabBarItem from "@normalized:N&&&entry/src/main/ets/common/TabBarItem&";
import BreakpointSystem from "@normalized:N&&&entry/src/main/ets/common/BreakpointSystem&";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.__currentBreakpoint = this.createStorageProp('currentBreakpoint', 'md', "currentBreakpoint");
        this.breakpointSystem = new BreakpointSystem();
        this.onTabChange = (index: number) => {
            this.currentIndex = index;
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.breakpointSystem !== undefined) {
            this.breakpointSystem = params.breakpointSystem;
        }
        if (params.onTabChange !== undefined) {
            this.onTabChange = params.onTabChange;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__currentBreakpoint.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        this.__currentBreakpoint.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentIndex: ObservedPropertySimplePU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    private __currentBreakpoint: ObservedPropertyAbstractPU<string>;
    get currentBreakpoint() {
        return this.__currentBreakpoint.get();
    }
    set currentBreakpoint(newValue: string) {
        this.__currentBreakpoint.set(newValue);
    }
    private breakpointSystem: BreakpointSystem;
    private onTabChange;
    aboutToAppear() {
        this.breakpointSystem.register();
    }
    aboutToDisappear() {
        this.breakpointSystem.unregister();
    }
    tabItem(index: number, title: Resource, icon: Resource, iconSelected: Resource, parent = null) {
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TabBarItem(this, {
                        index: index,
                        currentIndex: this.currentIndex,
                        title: title,
                        icon: icon,
                        iconSelected: iconSelected
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 25, col: 5 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            index: index,
                            currentIndex: this.currentIndex,
                            title: title,
                            icon: icon,
                            iconSelected: iconSelected
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        currentIndex: this.currentIndex
                    });
                }
            }, { name: "TabBarItem" });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 设置TabBar在主轴方向起始或结尾位置
            Tabs.create({ barPosition: this.currentBreakpoint === "lg" ? BarPosition.Start : BarPosition.End });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(36:5)", "entry");
            // 设置TabBar在主轴方向起始或结尾位置
            Tabs.backgroundColor('#F1F3F5');
            // 设置TabBar在主轴方向起始或结尾位置
            Tabs.barMode(BarMode.Fixed);
            // 设置TabBar在主轴方向起始或结尾位置
            Tabs.barWidth(this.currentBreakpoint === "lg" ? 96 : '100%');
            // 设置TabBar在主轴方向起始或结尾位置
            Tabs.barHeight(this.currentBreakpoint === "lg" ? '60%' : 56);
            // 设置TabBar在主轴方向起始或结尾位置
            Tabs.vertical(this.currentBreakpoint === "lg");
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new Home(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 39, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "Home" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.tabItem.call(this, 0, { "id": 16777266, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777273, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777234, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(38:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create();
            TabContent.tabBar({ builder: () => {
                    this.tabItem.call(this, 1, { "id": 16777267, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777231, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777232, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(44:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create();
            TabContent.tabBar({ builder: () => {
                    this.tabItem.call(this, 2, { "id": 16777268, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777282, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777274, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(48:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create();
            TabContent.tabBar({ builder: () => {
                    this.tabItem.call(this, 3, { "id": 16777269, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777284, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777272, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(53:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create();
            TabContent.tabBar({ builder: () => {
                    this.tabItem.call(this, 4, { "id": 16777286, "type": 10003, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777281, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" }, { "id": 16777274, "type": 20000, params: [], "bundleName": "szpu.edu.cn", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(58:7)", "entry");
        }, TabContent);
        TabContent.pop();
        // 设置TabBar在主轴方向起始或结尾位置
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "szpu.edu.cn", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
