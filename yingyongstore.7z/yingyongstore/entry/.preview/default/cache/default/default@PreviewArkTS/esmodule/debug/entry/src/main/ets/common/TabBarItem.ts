if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TabBarItem_Params {
    currentBreakpoint?: string;
    currentIndex?: number;
    index?: number;
    icon?: Resource;
    iconSelected?: Resource;
    title?: Resource;
}
interface GeneratedObjectLiteralInterface_1 {
    NORMAL: string;
    SELECTED: string;
}
const TitleColor: GeneratedObjectLiteralInterface_1 = {
    NORMAL: '#999',
    SELECTED: '#0A59F7'
};
export default class TabBarItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentBreakpoint = this.createStorageProp('currentBreakpoint', 'md', "currentBreakpoint");
        this.__currentIndex = new SynchedPropertySimpleOneWayPU(params.currentIndex, this, "currentIndex");
        this.index = undefined;
        this.icon = undefined;
        this.iconSelected = undefined;
        this.title = undefined;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TabBarItem_Params) {
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.icon !== undefined) {
            this.icon = params.icon;
        }
        if (params.iconSelected !== undefined) {
            this.iconSelected = params.iconSelected;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
    }
    updateStateVars(params: TabBarItem_Params) {
        this.__currentIndex.reset(params.currentIndex);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentBreakpoint.purgeDependencyOnElmtId(rmElmtId);
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentBreakpoint.aboutToBeDeleted();
        this.__currentIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentBreakpoint: ObservedPropertyAbstractPU<string>;
    get currentBreakpoint() {
        return this.__currentBreakpoint.get();
    }
    set currentBreakpoint(newValue: string) {
        this.__currentBreakpoint.set(newValue);
    }
    private __currentIndex: SynchedPropertySimpleOneWayPU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    private index?: number;
    private icon?: Resource;
    private iconSelected?: Resource;
    private title?: Resource;
    private getIcon() {
        return this.currentIndex === this.index ? this.iconSelected : this.icon;
    }
    private getFontColor() {
        return this.currentIndex === this.index ? TitleColor.SELECTED : TitleColor.NORMAL;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentBreakpoint !== 'md') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/common/TabBarItem.ets(30:7)", "entry");
                        Column.justifyContent(FlexAlign.Center);
                        Column.height('100%');
                        Column.width('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.getIcon());
                        Image.debugLine("entry/src/main/ets/common/TabBarItem.ets(31:9)", "entry");
                        Image.width(24);
                        Image.height(24);
                        Image.margin(5);
                        Image.objectFit(ImageFit.Contain);
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.title);
                        Text.debugLine("entry/src/main/ets/common/TabBarItem.ets(36:9)", "entry");
                        Text.fontColor(this.getFontColor());
                        Text.fontSize(12);
                        Text.fontWeight(500);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/common/TabBarItem.ets(42:7)", "entry");
                        Row.justifyContent(FlexAlign.Center);
                        Row.height('100%');
                        Row.width('100%');
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.getIcon());
                        Image.debugLine("entry/src/main/ets/common/TabBarItem.ets(43:9)", "entry");
                        Image.width(24);
                        Image.height(24);
                        Image.margin(5);
                        Image.objectFit(ImageFit.Contain);
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.title);
                        Text.debugLine("entry/src/main/ets/common/TabBarItem.ets(48:9)", "entry");
                        Text.fontColor(this.getFontColor());
                        Text.fontSize(12);
                        Text.fontWeight(500);
                    }, Text);
                    Text.pop();
                    Row.pop();
                });
            }
        }, If);
        If.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
