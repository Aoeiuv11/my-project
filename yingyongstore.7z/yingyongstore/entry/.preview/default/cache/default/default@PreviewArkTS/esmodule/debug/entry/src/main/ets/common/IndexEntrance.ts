if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface IndexEntrance_Params {
}
import { entranceIcons } from "@normalized:N&&&entry/src/main/ets/model/HomeData&";
import type { AppItem } from '../model/HomeDataType';
export default class IndexEntrance extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: IndexEntrance_Params) {
    }
    updateStateVars(params: IndexEntrance_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/IndexEntrance.ets(7:5)", "entry");
            Row.width('100%');
            Row.height(64);
            Row.justifyContent(FlexAlign.SpaceEvenly);
            Row.padding({ left: 12, right: 12 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //快捷入口关键代码
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const icon = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/common/IndexEntrance.ets(10:9)", "entry");
                    Column.width(56);
                    Column.height('100%');
                    Column.justifyContent(FlexAlign.Center);
                    Column.alignItems(HorizontalAlign.Center);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 直接使用图标资源
                    Image.create(icon.image);
                    Image.debugLine("entry/src/main/ets/common/IndexEntrance.ets(12:11)", "entry");
                    // 直接使用图标资源
                    Image.width(32);
                    // 直接使用图标资源
                    Image.height(32);
                    // 直接使用图标资源
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 直接使用国际化标题
                    Text.create(icon.title);
                    Text.debugLine("entry/src/main/ets/common/IndexEntrance.ets(18:11)", "entry");
                    // 直接使用国际化标题
                    Text.fontSize(12);
                    // 直接使用国际化标题
                    Text.margin({ top: 4 });
                }, Text);
                // 直接使用国际化标题
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, entranceIcons, forEachItemGenFunction);
        }, ForEach);
        //快捷入口关键代码
        ForEach.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
